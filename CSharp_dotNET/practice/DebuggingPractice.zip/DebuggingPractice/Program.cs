﻿// Challenge 1
bool amProgrammer = true;

double Age = 27.9;

List<string> names = new List<string>();
names.Add ("Monica");

Dictionary<string, string> MyDictionary = new Dictionary<string, string>();

MyDictionary.Add("Hello", "0");
MyDictionary.Add("Hi there", "0");
// This is a tricky one! Hint: look up what a char is in C#
string MyName = "MyName";
// Challenge 2
List<int> Numbers = new List<int>() { 2, 3, 6, 7, 1, 5 };
for (int i = 0; i < Numbers.Count; i++)
{
    Console.WriteLine(Numbers[i]);
}
// Challenge 3
List<int> MoreNumbers = new List<int>() { 12, 7, 10, -3, 9 };
foreach (int num in MoreNumbers)
{
    Console.WriteLine(num);
}
// Challenge 4
List<int> EvenMoreNumbers = new List<int> { 3, 6, 9, 12, 14 };
foreach (int num in EvenMoreNumbers)
{
    if (num % 3 == 0)
    {
        System.Console.WriteLine(num);
    }
}
// Challenge 5
// What can we learn from this error message?
string MyString = "superduberawesome";
// MyString[7] = "p";
// Challenge 6
// Hint: some bugs don't come with error messages
Random rand = new Random();
int randomNum = rand.Next(0, 11);
if (randomNum == 5)
{
    Console.WriteLine("Hello");
}

